class TreeNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

class BinarySearchTree:
    def __init__(self):
        self.root = None

    def insert(self, value):
        if not self.root:
            self.root = TreeNode(value)
        else:
            self._insert_recursive(self.root, value)

    def _insert_recursive(self, node, value):
        if value < node.value:
            if node.left is None:
                node.left = TreeNode(value)
            else:
                self._insert_recursive(node.left, value)
        else:
            if node.right is None:
                node.right = TreeNode(value)
            else:
                self._insert_recursive(node.right, value)

def are_identical(root1, root2):
    if root1 is None and root2 is None:
        return True
    if root1 is not None and root2 is not None:
        return (root1.value == root2.value and 
                are_identical(root1.left, root2.left) and
                are_identical(root1.right, root2.right))
    return False

def height(node):
    if node is None:
        return 0
    else:
        return max(height(node.left), height(node.right)) + 1

def find_min(node):
    current = node
    while current.left is not None:
        current = current.left
    return current.value

def find_max(node):
    current = node
    while current.right is not None:
        current = current.right
    return current.value


def find_max(node):
    current = node
    while current.right is not None:
        current = current.right
    return current.value


def is_balanced(node):
    if node is None:
        return True

    left_height = height(node.left)
    right_height = height(node.right)

    if (abs(left_height - right_height) <= 1) and is_balanced(node.left) is True and is_balanced(node.right) is True:
        return True

    return False


def is_symmetric(root):
    def is_mirror(node1, node2):
        if node1 is None and node2 is None:
            return True
        if node1 is not None and node2 is not None:
            return (node1.value == node2.value and 
                    is_mirror(node1.left, node2.right) and
                    is_mirror(node1.right, node2.left))
        return False
    
    return is_mirror(root, root)

bst = BinarySearchTree()
for value in [5, 3, 7, 2, 4, 6, 8]:
    bst.insert(value)

 
menor_elemento = find_min(bst.root)
print("O menor elemento é:", menor_elemento)   

 
maior_elemento = find_max(bst.root)
print("O maior elemento é:", maior_elemento)   

 
bst2 = BinarySearchTree()
for value in [5, 3, 7, 2, 4, 6, 8]:
    bst2.insert(value)

print("As árvores são idênticas:", are_identical(bst.root, bst2.root))   

 
altura = height(bst.root)
print("Altura da árvore:", altura)  

 
balanceada = is_balanced(bst.root)
print("A árvore é balanceada:", balanceada)   

 
simetrica = is_symmetric(bst.root)
print("A árvore é simétrica:", simetrica)   

  